package Lms;
// Custom JButton class

public class JButton extends javax.swing.JButton {
    public JButton(String text) {
        super(text);
    }
}
