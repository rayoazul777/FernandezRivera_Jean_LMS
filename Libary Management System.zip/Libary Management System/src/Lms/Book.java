package Lms;

/**
 * Author: Jean Fernandez Rivera
 * Course: CEN 3024C
 * Date: 09/03/2023
 * Class Name:
 * Description: Represents a single book in the library management system.
 */
import java.sql.*;
import java.util.ArrayList;

import java.util.concurrent.atomic.AtomicInteger;

public class Book {
    private static final AtomicInteger idCounter = new AtomicInteger(0);

    private int id;
    private String title;
    private String author;
    private String genre;
    private String status;
    private String dueDate;
    private String barcode;

    // Constructor for creating a new book
    public Book(String title, String author, String genre, String status, String dueDate, String barcode) {
        this.id = generateId();
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.status = status;
        this.dueDate = dueDate;
        this.barcode = barcode;
    }

    // Constructor for loading from the database
    public Book(int id, String title, String author, String status, String dueDate, String barcode) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.status = status;
        this.dueDate = dueDate;
        this.barcode = barcode;
    }

    private int generateId() {
        return idCounter.incrementAndGet();
    }

    // Getter and Setter methods

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public String getGenre() {
        return genre;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    public String getBarcode() {
        return barcode;
    }

    public void setBarcode(String barcode) {
        this.barcode = barcode;
    }

    public void setId(int id) {
        this.id = id;
    }

    @Override
    public String toString() {
        return id + ", " + title + ", " + author + ", " + genre + ", " + status + ", " + dueDate + ", " + barcode;
    }
}