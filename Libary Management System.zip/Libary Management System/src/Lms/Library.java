package Lms;

/**
 * Author: Jean Fernandez Rivera
 * Course: CEN 3024C
 * Date: 09/03/2023
 * Class Name:
 * Description: Represents a single book in the library management system.
 */
import java.sql.*;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;

public class Library {

    public static Library libraryInstance = new Library();
    private ArrayList<Book> books;

    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/library_management_system";
    private static final String USERNAME = "root";
    private static final String PASSWORD = "352688";

    private static final AtomicInteger idCounter = new AtomicInteger(0);

    public Library() {
        this.books = new ArrayList<>();
        loadFromDatabase();
    }

    public static Library getInstance() {
        return libraryInstance;
    }

    private void loadFromDatabase() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            String sql = "SELECT * FROM books";
            try (Statement statement = connection.createStatement()) {
                ResultSet resultSet = statement.executeQuery(sql);
                while (resultSet.next()) {
                    int id = resultSet.getInt("id");
                    String title = resultSet.getString("title");
                    String author = resultSet.getString("author");
                    String status = resultSet.getString("status");
                    String dueDate = resultSet.getString("due_date");
                    String barcode = resultSet.getString("barcode");

                    Book book = new Book(id, title, author, status, dueDate, barcode);
                    books.add(book);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void saveToDatabase() {
        try (Connection connection = DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD)) {
            connection.setAutoCommit(false);  // Start a transaction

            try (PreparedStatement deleteStatement = connection.prepareStatement("DELETE FROM books");
                 PreparedStatement insertStatement = connection.prepareStatement(
                         "INSERT INTO books (id, title, author, status, due_date, barcode) VALUES (?, ?, ?, ?, ?, ?)")) {

                // Delete all records
                deleteStatement.executeUpdate();

                // Insert new records
                for (Book book : libraryInstance.books) {
                    insertStatement.setInt(1, book.getId());  // Set id as an int
                    insertStatement.setString(2, book.getTitle());
                    insertStatement.setString(3, book.getAuthor());
                    insertStatement.setString(4, book.getStatus());
                    insertStatement.setString(5, book.getDueDate());
                    insertStatement.setString(6, book.getBarcode());
                    insertStatement.executeUpdate();
                }

                // Commit the transaction
                connection.commit();

            } catch (SQLException e) {
                // Rollback the transaction in case of an error
                connection.rollback();
                e.printStackTrace();
            } finally {
                // Set auto-commit back to true
                connection.setAutoCommit(true);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addBook(Book book) {
        books.add(book);
        book.setId(generateId());  // Set the generated ID for the added book
        saveToDatabase();  // Save to the database after adding a book
    }

    private int generateId() {
        return idCounter.incrementAndGet();
    }

    public void removeBookById(int id) {
        books.removeIf(book -> book.getId() == id);
        saveToDatabase();  // Save to the database after removing a book
    }

    public void removeBookByTitle(String title) {
        books.removeIf(book -> book.getTitle().equals(title));
        saveToDatabase();  // Save to the database after removing a book
    }

    public void removeBookByBarcode(String barcode) {
        books.removeIf(book -> book.getBarcode().equals(barcode));
        saveToDatabase();  // Save to the database after removing a book
    }

    public void checkoutBook(String title, String dueDate) {
        for (Book book : books) {
            if (book.getTitle().equals(title) && book.getStatus().equals("checked in")) {
                book.setStatus("checked out");
                book.setDueDate(dueDate);
                saveToDatabase();  // Save to the database after checking out a book
                return;
            }
        }
        System.out.println("Book not found or already checked out.");
    }

    public void checkinBook(String title, String barcode) {
        for (Book book : books) {
            if (book.getTitle().equals(title) && book.getStatus().equals("checked out") &&
                    book.getBarcode().equals(barcode)) {
                book.setStatus("checked in");
                book.setDueDate("null");
                saveToDatabase();  // Save to the database after checking in a book
                return;
            }
        }
        System.out.println("Book not found or already checked in.");
    }

    public void displayBooks() {
        for (Book book : books) {
            System.out.println(book.toString());
        }
    }

    public ArrayList<Book> getAllBooks() {
        return books;
    }

    public Book getBookByTitle(String title) {
        // Implement this method to retrieve a book by title
        return null;
    }
}


