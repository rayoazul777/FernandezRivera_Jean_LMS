package Lms;


import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LibraryManagementSystemGUI {
    private final JFrame frame;
    private final JButton loadButton;
    private final JButton printButton;
    private final JButton removeBarcodeButton;
    private final JButton removeTitleButton;
    private final JButton checkoutButton;
    private final JButton checkinButton;
    private final LibraryManagementSystem lms;

    public LibraryManagementSystemGUI(LibraryManagementSystem lms) {
        this.lms = lms;

        frame = new JFrame("Library Management System");
        frame.setSize(500, 500);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        loadButton = new JButton("Load");
        loadButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lms.loadFromDatabase();
                // Add code to refresh GUI if necessary
            }
        });
        frame.add(loadButton);

        printButton = new JButton("Print Books");
        printButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                lms.printBooks();
            }
        });
        frame.add(printButton);

        removeBarcodeButton = new JButton("Remove by Barcode");
        removeBarcodeButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String barcode = JOptionPane.showInputDialog("Enter Barcode:");
                lms.removeBookByBarcode(barcode);
            }
        });
        frame.add(removeBarcodeButton);

        removeTitleButton = new JButton("Remove by Title");
        removeTitleButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = JOptionPane.showInputDialog("Enter Title:");
                lms.removeBookByTitle(title);
            }
        });
        frame.add(removeTitleButton);

        checkoutButton = new JButton("Checkout Book");
        checkoutButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = JOptionPane.showInputDialog("Enter Title:");
                String barcode = JOptionPane.showInputDialog("Enter Barcode:");
                lms.checkoutBook(title, barcode);
            }
        });
        frame.add(checkoutButton);

        checkinButton = new JButton("Checkin Book");
        checkinButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String title = JOptionPane.showInputDialog("Enter Title:");
                String barcode = JOptionPane.showInputDialog("Enter Barcode:");
                lms.checkinBook(title, barcode);
            }
        });
        frame.add(checkinButton);

        frame.setVisible(true);
    }
}
