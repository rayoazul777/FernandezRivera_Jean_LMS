 package Lms;
/*
  Author: Jean Fernandez Rivera
  Course: CEN 3024C
  Date: 09/03/2023
  Class Name:
  Description: Represents a single book in the library management system.
 */

 import java.io.IOException;
 import java.sql.*;
 import java.util.Scanner;

 public class LibraryManagementSystem {

     private static Library library = new Library();
     private static LibraryManagementSystemGUI GUI;

     private static final String JDBC_URL = "jdbc:mysql://localhost:3306/library_management_system";
     private static final String USERNAME = "root";
     private static final String PASSWORD = "352688";

     private static Connection getConnection() throws SQLException {
         return DriverManager.getConnection(JDBC_URL, USERNAME, PASSWORD);
     }

     public static void loadFromDatabase() {
         try (Connection connection = getConnection()) {
             String query = "SELECT * FROM books";
             try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
                 ResultSet resultSet = preparedStatement.executeQuery();
                 while (resultSet.next()) {
                     int id = resultSet.getInt("id");
                     String title = resultSet.getString("title");
                     String author = resultSet.getString("author");
                     String genre = resultSet.getString("genre");
                     String status = resultSet.getString("status");
                     String dueDate = resultSet.getString("due_date");
                     String barcode = resultSet.getString("barcode");
                     var book = new Book(id, title, author, genre, status, dueDate);
                     library.addBook(book);
                 }
             }
         } catch (SQLException e) {
             e.printStackTrace();
         }
     }

     public static void saveToDatabase() {
         try (Connection connection = getConnection()) {
             String query = "INSERT INTO books (title, author, genre, status, due_date, barcode) VALUES (?, ?, ?, ?, ?, ?)";
             try (PreparedStatement preparedStatement = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                 for (Book book : library.getAllBooks()) {
                     preparedStatement.setString(1, book.getTitle());
                     preparedStatement.setString(2, book.getAuthor());
                     preparedStatement.setString(3, book.getGenre());
                     preparedStatement.setString(4, book.getStatus());
                     preparedStatement.setString(5, book.getDueDate());
                     preparedStatement.setString(6, book.getBarcode());
                     preparedStatement.executeUpdate();

                     ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                     if (generatedKeys.next()) {
                         int id = generatedKeys.getInt(1);
                         book.setId(id);
                     }
                 }
             }
         } catch (SQLException e) {
             e.printStackTrace();
         }
     }

     public static void printBooks() {
         library.displayBooks();
     }

     public static void removeBookByBarcode(String barcode) {
         library.removeBookByBarcode(barcode);
     }

     public static void removeBookByTitle(String title) {
         library.removeBookByTitle(title);
     }

     public static void checkoutBook(String title, String barcode) {
         library.checkoutBook(title, barcode);
     }

     public static void checkinBook(String title, String barcode) {
         library.checkinBook(title, barcode);
     }

     public static void main(String[] args) {
         loadFromDatabase();

         LibraryManagementSystemGUI gui = new LibraryManagementSystemGUI(new LibraryManagementSystem());
         setGUI(gui);

         Scanner scanner = new Scanner(System.in);
         while (true) {
             System.out.println("1. Add new book");
             System.out.println("2. Remove a book by ID");
             System.out.println("3. Remove a book by title");
             System.out.println("4. List all books");
             System.out.println("5. Check out a book by title and barcode");
             System.out.println("6. Check in a book by title and barcode");
             System.out.println("7. Exit");

             String choice = scanner.nextLine();
             switch (choice) {
                 case "1":
                     System.out.println("Enter book title: ");
                     String title = scanner.nextLine();
                     System.out.println("Enter book author: ");
                     String author = scanner.nextLine();
                     System.out.println("Enter book genre: ");
                     String genre = scanner.nextLine();
                     System.out.println("Enter book status (checked in/checked out): ");
                     String status = scanner.nextLine();
                     System.out.println("Enter book due date (YYYY-MM-DD): ");
                     String dueDate = scanner.nextLine();
                     System.out.println("Enter book barcode: ");
                     String barcode = scanner.nextLine();
                     library.addBook(new Book(title, author, genre, status, dueDate, barcode));
                     break;
                 case "2":
                     System.out.println("Enter the barcode of the book to remove: ");
                     String removeBarcode = scanner.nextLine();
                     removeBookByBarcode(removeBarcode);
                     break;
                 case "3":
                     System.out.println("Enter the title of the book to remove: ");
                     String removeTitle = scanner.nextLine();
                     removeBookByTitle(removeTitle);
                     break;
                 case "4":
                     printBooks();
                     break;
                 case "5":
                     System.out.println("Enter the title of the book to check out: ");
                     String checkoutTitle = scanner.nextLine();
                     System.out.println("Enter the barcode of the book to check out: ");
                     String checkoutBarcode = scanner.nextLine();
                     checkoutBook(checkoutTitle, checkoutBarcode);
                     break;
                 case "6":
                     System.out.println("Enter the title of the book to check in: ");
                     String checkinTitle = scanner.nextLine();
                     System.out.println("Enter the barcode of the book to check in: ");
                     String checkinBarcode = scanner.nextLine();
                     checkinBook(checkinTitle, checkinBarcode);
                     break;
                 case "7":
                     saveToDatabase();
                     System.out.println("Exiting. Goodbye!");
                     return;
                 default:
                     System.out.println("Invalid choice. Please try again.");
             }
         }
     }

     public static void setGUI(LibraryManagementSystemGUI GUI) {
         LibraryManagementSystem.GUI = GUI;
     }
 }