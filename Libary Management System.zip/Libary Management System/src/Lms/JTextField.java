package Lms; // Make sure this package name matches your project's package structure

// Custom JTextField class
public class JTextField extends javax.swing.JTextField {
    public JTextField(int columns) {
        super(columns);
    }
}
