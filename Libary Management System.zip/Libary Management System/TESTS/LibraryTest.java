import org.junit.Test;
import static org.junit.Assert.*;

public class LibraryTest {

    @Test
    public void testAddBook() {
        Library library = new Library();
        Book book = new Book(1, "Test Book", "Test Author", "12345");
        library.addBook(book);

        // Check if the book was added
        assertEquals(1, library.getBooks().length);
    }
}


public class LibraryTest {

    @Test
    public void testRemoveBookByBarcode() {
        Library library = new Library();
        Book book = new Book(1, "Test Book", "Test Author", "12345");
        library.addBook(book);

        // Remove the book by barcode
        library.removeBookByBarcode("12345");

        // Check if the book was removed
        assertEquals(0, library.getBooks().length);
    }
}

public class LibraryTest {

    @Test
    public void testRemoveBookByTitle() {
        Library library = new Library();
        Book book = new Book(1, "Test Book", "Test Author", "12345");
        library.addBook(book);

        // Remove the book by title
        library.removeBookByTitle("Test Book");

        // Check if the book was removed
        assertEquals(0, library.getBooks().length);
    }
}
public class LibraryTest {

    @Test
    public void testCheckOutBook() {
        Library library = new Library();
        Book book = new Book(1, "Test Book", "Test Author", "12345");
        library.addBook(book);

        // Check out the book
        library.checkoutBook("Test Book");

        // Get the book from the library
        Book checkedOutBook = library.getBookByTitle("Test Book");

        // Check if the due date is set
        assertNotNull(checkedOutBook.getDueDate());
    }
}

public class LibraryTest {

    @Test
    public void testCheckInBook() {
        Library library = new Library();
        Book book = new Book(1, "Test Book", "Test Author", "12345");
        library.addBook(book);

        // Check out the book
        library.checkoutBook("Test Book");

        // Check in the book
        library.checkinBook("Test Book");

        // Get the book from the library
        Book checkedInBook = library.getBookByTitle("Test Book");

        // Check if the due date is null
        assertNull(checkedInBook.getDueDate());
    }
}